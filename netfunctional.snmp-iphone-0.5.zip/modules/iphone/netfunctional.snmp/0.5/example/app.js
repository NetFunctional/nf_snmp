var snmpModule = require('netfunctional.snmp');
Ti.API.info("module is => " + snmpModule);